package com.example.mytodolist;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

public class FileOperationActivity extends AppCompatActivity {

    static final int MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE = 123456;

    static final String FILENAME = "what.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_operation);

        final Button btnPath = findViewById(R.id.fileIO_print_path_btn);
        final Button btnWrite = findViewById(R.id.fileIO_write_btn);
        final Button btnRead = findViewById(R.id.fileIO_read_btn);

        final TextView path = findViewById(R.id.tv_print_path);
        final TextView content = findViewById(R.id.tv_read_file);

        final EditText writes = findViewById(R.id.edit_write_file);

        btnPath.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                StringBuilder str = new StringBuilder();
                str.append("===== Internal Private =====\n").append(getInternalPath())
                        .append("===== External Private =====\n").append(getExternalPrivatePath())
                        .append("===== External Public =====\n").append(getExternalPublicPath());
                path.setText(str);
            }
        });

        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED)
        {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE);
        }

        btnWrite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED)
                {
                    requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                            MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE);
                }

                //Although there is a request for external storage write, the app actually write/read in internal storage
                //Because I want this app to delete all the files it created from my mobile phone when uninstalling it.
                File file = new File(getFilesDir() + "/" + FILENAME);
                FileWriter writer = null;
                try
                {
                    writer = new FileWriter(file);
                    if(!file.exists()) file.createNewFile();
                    writer.write(writes.getText().toString());
                    writer.close();
                }
                catch (IOException x)
                {
                    Toast.makeText(FileOperationActivity.this, "exception", Toast.LENGTH_SHORT).show();
                }
                finally {
                    try{
                        if(writer != null) writer.close();
                    }catch(IOException x)
                    {
                        Toast.makeText(FileOperationActivity.this, "File Close Failed", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        btnRead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED)
                {
                    requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                            MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE);
                }

                //Although there is a request for external storage write, the app actually write/read in internal storage
                //Because I want this app to delete all the files it created from my mobile phone when uninstalling it.
                File file = new File(getFilesDir() + "/" + FILENAME);
                FileReader reader = null;
                try
                {
                    if(!file.exists()) throw (new IOException("File not found! Please Write First!"));
                    reader = new FileReader(file);
                    char[] buffer = new char[100];
                    reader.read(buffer);
                    String s = new String(buffer);
                    content.setText(s);
                    reader.close();
                }
                catch (IOException x)
                {
                    Toast.makeText(FileOperationActivity.this, x.getMessage(), Toast.LENGTH_SHORT).show();
                }
                finally {
                    try{
                        if(reader != null) reader.close();
                    }catch(IOException x)
                    {
                        Toast.makeText(FileOperationActivity.this, "File Close Failed", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });

    }




    //////////////////////////////////The part below here is copied from the demo////////////////////////////
    private String getInternalPath() {
        Map<String, File> dirMap = new LinkedHashMap<>();
        dirMap.put("cacheDir", getCacheDir());
        dirMap.put("filesDir", getFilesDir());
        dirMap.put("customDir", getDir("custom", MODE_PRIVATE));
        return getCanonicalPath(dirMap);
    }

    private String getExternalPrivatePath() {
        Map<String, File> dirMap = new LinkedHashMap<>();
        dirMap.put("cacheDir", getExternalCacheDir());
        dirMap.put("filesDir", getExternalFilesDir(null));
        dirMap.put("picturesDir", getExternalFilesDir(Environment.DIRECTORY_PICTURES));
        return getCanonicalPath(dirMap);
    }

    private String getExternalPublicPath() {
        Map<String, File> dirMap = new LinkedHashMap<>();
        dirMap.put("rootDir", Environment.getExternalStorageDirectory());
        dirMap.put("picturesDir",
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES));
        return getCanonicalPath(dirMap);
    }

    private static String getCanonicalPath(Map<String, File> dirMap) {
        StringBuilder sb = new StringBuilder();
        try {
            for (String name : dirMap.keySet()) {
                sb.append(name)
                        .append(": ")
                        .append(dirMap.get(name).getCanonicalPath())
                        .append('\n');
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }
}
