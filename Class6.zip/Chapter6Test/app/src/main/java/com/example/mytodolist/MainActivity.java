package com.example.mytodolist;

import com.example.mytodolist.ToDoListContract.ToDoTupleInfo;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public class Task {

        public int id;
        public String content;
        public String timestamp;
        public int done;
        public int priority;

    }

    public class TaskViewHolder extends RecyclerView.ViewHolder {

        private CheckBox done;
        private TextView content;
        private TextView time;
        private Button delete;
        private View thisView;

        public TaskViewHolder(@NonNull View itemView) {
            super(itemView);
            thisView = itemView;
            done = thisView.findViewById(R.id.task_checkbox_done);
            content = thisView.findViewById(R.id.task_content);
            time = thisView.findViewById(R.id.task_timestamp);
            delete = thisView.findViewById(R.id.task_btn_delete);
        }

        public void bind(final Activity activity, final Task task)
        {
            switch (task.priority)
            {
                case 2:
                    thisView.setBackgroundColor(Color.YELLOW);
                    break;
                case 3:
                    thisView.setBackgroundColor(Color.RED);
                    break;
            }
            content.setText(task.content);
            time.setText(task.timestamp);
            if(task.done == 1)
            {
                done.setChecked(true);
                content.setTextColor(Color.GRAY);
                content.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG);
            }
            else
            {
                content.setTextColor(Color.BLACK);
                content.getPaint().setFlags(content.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
            }
            done.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                    if(done.isChecked())
                    {
                        task.done = 1;
                        content.setTextColor(Color.GRAY);
                        content.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG);
                    }
                    else
                    {
                        task.done = 0;
                        content.setTextColor(Color.BLACK);
                        content.getPaint().setFlags(content.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
                    }
                    updateTask(task);
                }
            });
            delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    deleteTask(task);
                }
            });
        }
    }

    public class TaskAdapter extends RecyclerView.Adapter<TaskViewHolder> {

        List<Task> mList;
        Activity thisAct;

        public TaskAdapter(Activity act, List<Task> vList)
        {
            mList = vList;
            thisAct = act;
        }

        public void refresh(List<Task> vList)
        {
            mList.clear();
            mList.addAll(vList);
            RecyclerView mRv = findViewById(R.id.rv_todolist);
            mRv.setAdapter(this);
            //notifyDataSetChanged();
        }

        @NonNull
        @Override
        public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.layout_one_task, viewGroup, false);
            TaskViewHolder holder = new TaskViewHolder(view);
            return holder;
        }

        @Override
        public void onBindViewHolder(@NonNull TaskViewHolder holder, int pos) {
            Task t = mList.get(pos);
            holder.bind(thisAct, t);
        }

        @Override
        public int getItemCount() {
            return mList.size();
        }

    }

    private SQLiteDatabase database;
    private ToDoListDBHelper dbHelper;
    private TaskAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        dbHelper = new ToDoListDBHelper(this);
        database = dbHelper.getWritableDatabase();

        setContentView(R.layout.activity_main);
        setTitle("To Do List (File IO ------------->)");
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        final RecyclerView taskRv = findViewById(R.id.rv_todolist);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, EditNoteActivity.class);
                startActivity(intent);
                taskRv.setAdapter(new TaskAdapter(MainActivity.this, loadTasksFromDatabase()));
            }
        });
        taskRv.setLayoutManager(new LinearLayoutManager(this));
        taskRv.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

        adapter = new TaskAdapter(MainActivity.this, loadTasksFromDatabase());
        taskRv.setAdapter(adapter);
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        adapter.mList = loadTasksFromDatabase();
        final RecyclerView taskRv = findViewById(R.id.rv_todolist);
        taskRv.setAdapter(adapter);
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        database.close();
        database = null;
        dbHelper.close();
        dbHelper = null;
    }

////////////////////////////////////////////////DB OPERATIONS//////////////////////////////////////////////////

    private List<Task> loadTasksFromDatabase()
    {
        if(database == null)
        {
            return Collections.emptyList();
        }
        List<Task> ret = new ArrayList<>();
        Cursor cursor = null;
        try
        {
            cursor = database.query(ToDoListContract.ToDoTupleInfo.TABLE_NAME, null,
                    null, null, null, null, ToDoTupleInfo.COLUMN_PRIORITY + " DESC");
            while(cursor.moveToNext())
            {
                int id = cursor.getInt(cursor.getColumnIndex(ToDoTupleInfo._ID));
                String time = cursor.getString(cursor.getColumnIndex(ToDoTupleInfo.COLUMN_TIME));
                int done = cursor.getInt(cursor.getColumnIndex(ToDoTupleInfo.COLUMN_DONE));
                int pri = cursor.getInt(cursor.getColumnIndex(ToDoTupleInfo.COLUMN_PRIORITY));
                String content = cursor.getString(cursor.getColumnIndex(ToDoTupleInfo.COLUMN_CONTENT));

                Task task = new Task();
                task.content = content;
                task.done = done;
                task.timestamp = time;
                task.priority = pri;
                task.id = id;

                ret.add(task);
            }
        } finally {
            if(cursor != null) cursor.close();
        }
        return ret;
    }

    private void deleteTask(Task task)
    {
        if (database == null) return;
        int rows = database.delete(ToDoTupleInfo.TABLE_NAME, ToDoTupleInfo._ID + "=?", new String[]{String.valueOf(task.id)});
        if (rows > 0) adapter.refresh(loadTasksFromDatabase());
    }

    private void updateTask(Task task)
    {
        if (database == null) return;
        ContentValues values = new ContentValues();
        values.put(ToDoTupleInfo.COLUMN_DONE, task.done);
        values.put(ToDoTupleInfo.COLUMN_CONTENT, task.content);
        values.put(ToDoTupleInfo.COLUMN_PRIORITY, task.priority);
        values.put(ToDoTupleInfo.COLUMN_TIME, task.timestamp);

        int rows = database.update(ToDoTupleInfo.TABLE_NAME, values,
                ToDoTupleInfo._ID + "=?",
                new String[]{String.valueOf(task.id)});

    }



////////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.fileIO) {
            Intent intent = new Intent(MainActivity.this, FileOperationActivity.class);
            this.startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
////////////////////////////////////////////////////////////////////////////////////////////////////
}
