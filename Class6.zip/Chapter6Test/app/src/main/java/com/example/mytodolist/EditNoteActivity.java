package com.example.mytodolist;

import com.example.mytodolist.ToDoListContract.ToDoTupleInfo;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import java.util.Calendar;

public class EditNoteActivity extends AppCompatActivity {

    private ToDoListDBHelper dbHelper;
    private SQLiteDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_note);
        setTitle("New Task");

        dbHelper = new ToDoListDBHelper(this);
        database = dbHelper.getWritableDatabase();

        final EditText edit = findViewById(R.id.edit_new_text);
        edit.setFocusable(true);
        edit.requestFocus();

        final RadioButton rlow = findViewById(R.id.priority_1);
        final RadioButton rmed = findViewById(R.id.priority_2);
        final RadioButton rhigh = findViewById(R.id.priority_3);
        rlow.setChecked(true);

        Button btnAdd = findViewById(R.id.btn_add);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String content = edit.getText().toString();
                if(content.length() == 0)
                {
                    Toast.makeText(EditNoteActivity.this, "Please input content", Toast.LENGTH_SHORT).show();
                    return;
                }
                int pri = 1;
                if(rlow.isChecked()) pri = 1;
                else if(rmed.isChecked()) pri = 2;
                else if(rhigh.isChecked()) pri = 3;
                boolean succeed = saveTaskToDB(content, pri);

                if (succeed) {
                    Toast.makeText(EditNoteActivity.this,
                            "Note added", Toast.LENGTH_SHORT).show();
                    setResult(Activity.RESULT_OK);
                } else {
                    Toast.makeText(EditNoteActivity.this,
                            "Error", Toast.LENGTH_SHORT).show();
                }
                finish();
            }
        });

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        database.close();
        database = null;
        dbHelper.close();
        dbHelper = null;
    }


    private boolean saveTaskToDB(String content, int priority) {
        if (database == null || TextUtils.isEmpty(content)) {
            return false;
        }
        ContentValues values = new ContentValues();
        values.put(ToDoTupleInfo.COLUMN_CONTENT, content);
        values.put(ToDoTupleInfo.COLUMN_PRIORITY, priority);
        values.put(ToDoTupleInfo.COLUMN_DONE, 0);
        Calendar cal = Calendar.getInstance();
        values.put(ToDoTupleInfo.COLUMN_TIME, cal.getTime().toString());
        long rowId = database.insert(ToDoTupleInfo.TABLE_NAME, null, values);
        return rowId != -1;
    }

}
