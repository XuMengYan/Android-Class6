package com.example.mytodolist;

import android.provider.BaseColumns;

public final class ToDoListContract {

    public static final String SQL_CREATE_TABLE =
            "CREATE TABLE " + ToDoTupleInfo.TABLE_NAME
            + "(" + ToDoTupleInfo._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + ToDoTupleInfo.COLUMN_TIME + " TEXT, "
            + ToDoTupleInfo.COLUMN_CONTENT + " TEXT, "
            + ToDoTupleInfo.COLUMN_DONE + " INTEGER, "
            + ToDoTupleInfo.COLUMN_PRIORITY + " INTEGER)";

    public static final String SQL_ADD_PRIORITY =
            "ALTER TABLE " + ToDoTupleInfo.TABLE_NAME + " ADD " + ToDoTupleInfo.COLUMN_PRIORITY + " INTEGER";

    private ToDoListContract(){}

    public static class ToDoTupleInfo implements BaseColumns{
        public static final String TABLE_NAME = "todolist";
        public static final String COLUMN_TIME = "date";
        public static final String COLUMN_CONTENT = "content";
        public static final String COLUMN_DONE = "done";
        public static final String COLUMN_PRIORITY = "priority";
    }


}
