package com.example.mytodolist;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ToDoListDBHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "todolist.db";
    private static final int DB_VERSION = 2;

    public ToDoListDBHelper(Context context)
    {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(ToDoListContract.SQL_CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldv, int newv) {
        for (int i = oldv; i < newv; i++) {
            switch (i) {
                case 1:
                    db.execSQL(ToDoListContract.SQL_ADD_PRIORITY);
                    break;
            }
        }
    }
}
